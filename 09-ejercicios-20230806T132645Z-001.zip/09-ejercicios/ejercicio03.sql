/* 
3. Incrementar el precio de los coches en un dos poriciento.
 */

UPDATE coches SET precio = precio*1.05;

