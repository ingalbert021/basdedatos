/* 
7. Mostrar el nombre y el salario de los vendedores con cargo de 'Ayudante en tienda'
 */

SELECT nombre, sueldo FROM vendedores WHERE cargo='Ayudante en tienda';

